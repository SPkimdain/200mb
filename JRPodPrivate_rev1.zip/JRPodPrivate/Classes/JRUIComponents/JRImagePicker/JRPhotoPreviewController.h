//
//  JRPhotoPreviewController.h
//  JRPodPrivate_Example
//
//  Created by 金煜祥 on 2020/9/22.
//  Copyright © 2020 wni. All rights reserved.
//
#import "JRUIKit.h"
NS_ASSUME_NONNULL_BEGIN

@interface JRPhotoPreviewController : TZPhotoPreviewController
@property (nonatomic,assign)BOOL onlyShowSelectModel;
@end

NS_ASSUME_NONNULL_END
