//
//  TZAssetModel+JRAddProperty.h
//  JRPodPrivate_Example
//
//  Created by 金煜祥 on 2020/9/25.
//  Copyright © 2020 wni. All rights reserved.
//
#import "JRUIKit.h"
NS_ASSUME_NONNULL_BEGIN

@interface TZAssetModel (JRAddProperty)
@property(nonatomic,strong)UIImage * thumbImage;
@end

NS_ASSUME_NONNULL_END
