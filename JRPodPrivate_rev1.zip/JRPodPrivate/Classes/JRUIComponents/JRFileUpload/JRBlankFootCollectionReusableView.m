//
//  JRBlankFootCollectionReusableView.m
//  JRPodPrivate
//
//  Created by 金煜祥 on 2021/2/1.
//

#import "JRBlankFootCollectionReusableView.h"

@implementation JRBlankFootCollectionReusableView

@end
