/**
 * 所属系统: K信
 * 所属模块: 公共
 * 功能描述: 上拉加载
 * 创建时间: 2016/7/21
 * 维护人:  张子飞
 * Copyright @ Jerrisoft 2019. All rights reserved.
 *┌─────────────────────────────────────────────────────┐
 *│ 此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．│
 *│ 版权所有：杰人软件(深圳)有限公司                          │
 *└─────────────────────────────────────────────────────┘
 */


#import "MJRefreshAutoFooter.h"

@interface JRRefreshFooter : MJRefreshAutoFooter

@end
