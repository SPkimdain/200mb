//
//  JRCalendarCollectionView.h
//  JRCalendar
//
//  Created by Wenchao Ding on 10/25/15.
//  Copyright (c) 2015 Wenchao Ding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JRCalendarCollectionView : UICollectionView

@end


@interface JRCalendarSeparator : UICollectionReusableView

@end
