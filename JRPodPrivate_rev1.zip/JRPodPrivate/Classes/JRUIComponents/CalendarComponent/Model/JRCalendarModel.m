
//
//  AttendanceSemesterModel.m
//  ManagementPlatform
//
//  Created by 李志䶮 on 2020/9/19.
//  Copyright © 2020年 ITUser. All rights reserved.
//

#import "JRCalendarModel.h"

@implementation JRCalendarModel

@end
