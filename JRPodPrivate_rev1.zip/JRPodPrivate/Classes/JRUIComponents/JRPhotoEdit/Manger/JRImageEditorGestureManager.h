//
//  WBGImageEditorGestureManager.h
//  CLImageEditorDemo
//
//  Created by Jason on 2017/3/3.
//  Copyright © 2017年 CALACULU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JRImageEditorGestureManager : NSObject <UIGestureRecognizerDelegate>
+ (instancetype)instance;
@end
