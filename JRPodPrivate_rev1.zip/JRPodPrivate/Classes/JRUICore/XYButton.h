//
//  XYButton.h
//  ArtLibrary
//
//  Created by JRuser on 16/5/23.
//  Copyright © 2016年 JRuser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYButton : UIButton

@end
