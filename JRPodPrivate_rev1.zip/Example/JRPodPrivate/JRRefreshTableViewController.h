//
//  JRRefreshTableViewController.h
//  JRPodPrivate_Example
//
//  Created by 金煜祥 on 2021/4/9.
//  Copyright © 2021 wni. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JRRefreshTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
