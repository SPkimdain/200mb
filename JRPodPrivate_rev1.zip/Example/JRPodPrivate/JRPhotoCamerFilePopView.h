//
//  JRPhotoCamerFilePopView.h
//  JRPodPrivate_Example
//
//  Created by J0224 on 2020/11/24.
//  Copyright © 2020 wni. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JRPhotoCameraFilePopView : UIView

@end

NS_ASSUME_NONNULL_END
