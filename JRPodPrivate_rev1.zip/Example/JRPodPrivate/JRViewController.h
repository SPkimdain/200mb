//
//  JRViewController.h
//  JRPodPrivate
//
//  Created by wni on 09/18/2020.
//  Copyright (c) 2020 wni. All rights reserved.
//

@import UIKit;

@interface JRViewController : UIViewController

@end
