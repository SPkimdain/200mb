//
//  main.m
//  JRPodPrivate
//
//  Created by wni on 09/18/2020.
//  Copyright (c) 2020 wni. All rights reserved.
//

@import UIKit;
#import "JRAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
                
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JRAppDelegate class]));
    }
}
