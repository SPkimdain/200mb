//
//  JRImageModel.m
//  JRPodPrivate_Example
//
//  Created by 朱俊彪 on 2021/2/9.
//  Copyright © 2021 wni. All rights reserved.
//

#import "JRImageModel.h"

@implementation JRImageModel

@end
